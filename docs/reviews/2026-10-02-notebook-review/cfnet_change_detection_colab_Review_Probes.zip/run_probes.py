"""Probes for the Notebook Review Framework v1 review of tutorials/cfnet_change_detection_colab.ipynb.

CPU only. Code cells are executed verbatim from the notebook JSON in one namespace; only form-field literals are
substituted and google.colab.files.upload is replaced by a fake. Install cell runs with
DIMER_NOTEBOOK_CI_PREINSTALLED=1 (the environment already holds the exact pins, CPU torch builds).
The pinned checkpoint, its README and the 192 pinned crops are hard-linked from the maintainer's cache into a
scratch work directory; the notebook writes its own manifest and converts the checkpoint itself.

usage: python run_probes.py NOTEBOOK REPO_WEIGHTS_DIR WORK_DIR RESULTS_JSON
"""
from __future__ import annotations

import io
import json
import os
import re
import sys
import time
import traceback
import types
import zipfile
from pathlib import Path

NB, SRC_WEIGHTS, WORK, OUT = (Path(a) for a in sys.argv[1:5])
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ.setdefault('KMP_DUPLICATE_LIB_OK', 'TRUE')

results: dict = {'notebook': str(NB), 'probes': {}}


def save():
    OUT.write_text(json.dumps(results, indent=2, default=str), encoding='utf-8')


cells = json.loads(NB.read_text(encoding='utf-8'))['cells']
code = {i: ''.join(c['source']) for i, c in enumerate(cells) if c['cell_type'] == 'code'}
results['code_cells'] = sorted(code)


def setparam(src: str, name: str, value: str) -> str:
    new, n = re.subn(rf'^{name} = [^#\n]*', f'{name} = {value}  ', src, count=1, flags=re.M)
    assert n == 1, name
    return new


# --- fake google.colab -------------------------------------------------------------------------------
UPLOAD: dict = {}
google = types.ModuleType('google')
colab = types.ModuleType('google.colab')
files_mod = types.ModuleType('google.colab.files')
files_mod.upload = lambda: dict(UPLOAD)
colab.files = files_mod
google.colab = colab
sys.modules.update({'google': google, 'google.colab': colab, 'google.colab.files': files_mod})

# --- scratch work dir -------------------------------------------------------------------------------
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
wdir = WORK / 'weights' / 'cfnet-levir-cd'
wdir.mkdir(parents=True, exist_ok=True)
for name in ('levir-cd.pth', 'README.md'):  # not the manifest (the notebook writes it) and not the safetensors
    if not (wdir / name).exists():
        os.link(SRC_WEIGHTS / 'cfnet-levir-cd' / name, wdir / name)
crops = WORK / 'weights' / 'levir-cd' / 'crops'
crops.mkdir(parents=True, exist_ok=True)
for f in (SRC_WEIGHTS / 'levir-cd' / 'crops').iterdir():
    if not (crops / f.name).exists():
        os.link(f, crops / f.name)
results['linked'] = {'checkpoint': 2, 'crops': len(list(crops.iterdir())), 'tarball_linked': False}

ns: dict = {'__name__': '__main__'}


def run(i: int, src: str | None = None):
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    t0 = time.perf_counter()
    err = None
    try:
        exec(compile(src if src is not None else code[i], f'<cell {i}>', 'exec'), ns)
    except BaseException as exc:  # noqa: BLE001
        err = f'{type(exc).__name__}: {exc}'[:600]
        tb = traceback.format_exc()
        err_tb = tb[-1500:]
    finally:
        sys.stdout = old
    out = buf.getvalue()
    rec = {'cell': i, 'seconds': round(time.perf_counter() - t0, 1), 'ok': err is None, 'stdout_tail': out[-2500:]}
    if err:
        rec['error'] = err
        rec['traceback_tail'] = err_tb
    print(f'cell {i}: ok={err is None} {rec["seconds"]}s', err or '', flush=True)
    return rec


# ---------------- P1: default path ----------------
p1 = []
for i in sorted(code):
    p1.append(run(i))
    if not p1[-1]['ok']:
        break
results['probes']['P1_default'] = p1
save()
ok_default = all(r['ok'] for r in p1)
if ok_default:
    results['probes']['P1_summary'] = {
        'comparison': ns['comparison'],
        'history': [{k: e.get(k) for k in ('epoch', 'train_loss', 'val_loss')} | {'val_f1': e.get('val', {}).get('f1')} for e in ns['adapt_result']['history']],
        'best_epoch': ns['adapt_result']['best_epoch'],
        'parity': ns['parity'],
        'outputs': sorted(p.as_posix() for p in Path('outputs').rglob('*') if p.is_file()),
    }
    save()

# ---------------- P2: documented experiment rerun on the same kernel: TRAINABLE='decoders' ----------------
if ok_default:
    first_kept_val_loss = ns['adapt_result']['history'][ns['adapt_result']['best_epoch']]['val_loss']
    frozen_val_loss = ns['adapt_result']['history'][0]['val_loss']
    src19 = setparam(code[19], 'TRAINABLE', "'decoders'")
    p2 = [run(19, src19), run(21), run(23)]
    h = ns['adapt_result']['history']
    report = json.loads(Path('outputs/cfnet_change_detection_evaluation_report.json').read_text(encoding='utf-8'))
    results['probes']['P2_decoders_rerun'] = {
        'cells': p2,
        'epoch0_note': h[0].get('note'),
        'epoch0_val_loss_rerun': h[0]['val_loss'],
        'true_frozen_val_loss': frozen_val_loss,
        'previous_kept_val_loss': first_kept_val_loss,
        'best_epoch': ns['adapt_result']['best_epoch'],
        'report_history0_note': report['history'][0].get('note'),
        'report_history0_val_loss': report['history'][0]['val_loss'],
    }
    save()

    # ---------------- P3: next documented experiment: LEARNING_RATE = 1e-3, TRAINABLE back to default ----------------
    src19b = setparam(setparam(code[19], 'LEARNING_RATE', '1e-3'), 'TRAINABLE', "'change_decoder'")
    p3 = [run(19, src19b), run(21), run(23)]
    results['probes']['P3_lr1e-3_after_decoders'] = {
        'cells': p3,
        'best_epoch': ns['adapt_result']['best_epoch'],
        'history': [{'epoch': e['epoch'], 'val_loss': e['val_loss'], 'val_f1': e.get('val', {}).get('f1')} for e in ns['adapt_result']['history']],
        'parity': ns.get('parity'),
    }
    save()

# ---------------- P4: LR=1e-3 from a fresh base (rebuild pipe via cell 13) ----------------
if ok_default:
    p4 = [run(13), run(17), run(19, setparam(code[19], 'LEARNING_RATE', '1e-3')), run(21), run(23)]
    results['probes']['P4_lr1e-3_fresh'] = {
        'cells': p4,
        'best_epoch': ns['adapt_result']['best_epoch'],
        'history': [{'epoch': e['epoch'], 'val_loss': e['val_loss'], 'val_f1': e.get('val', {}).get('f1')} for e in ns['adapt_result']['history']],
        'comparison': ns.get('comparison'),
    }
    save()


# ---------------- P5: BYOD (Section 4 + Section 5) with real LEVIR-CD crops written in the BYOD shape --------
def byod_zip(records, *, prefix='', drop_csv=False, cols=('id', 'before', 'after', 'label'), missing_member=False):
    import numpy as np
    from PIL import Image

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        rows = []
        for k, r in enumerate(records):
            names = {}
            for part in ('before', 'after', 'label'):
                arr = r[part] if part != 'label' else np.where(r['label'] == 1, 255, 0).astype('uint8')
                b = io.BytesIO()
                Image.fromarray(arr).save(b, format='PNG')
                names[part] = f'{prefix}p{k}_{part}.png'
                if not (missing_member and k == 0 and part == 'after'):
                    z.writestr(names[part], b.getvalue())
            rows.append({'id': f'p{k}', **names})
        if not drop_csv:
            lines = [','.join(cols)] + [','.join(row[c] for c in cols) for row in rows]
            z.writestr('pairs.csv', '\n'.join(lines) + '\n')
    return buf.getvalue()


if ok_default:
    base_records = ns['test_records'] + ns['val_records']
    p5: dict = {}
    # minimum pair count actually enforced by split_dataset (stated: "at least four pairs")
    counts = {}
    for n in range(4, 10):
        zp = WORK / f'n{n}.zip'
        zp.write_bytes(byod_zip(base_records[:n]))
        try:
            s = ns['split_dataset'](ns['load_byod_dataset'](zp), seed=0)
            counts[n] = {k: len(v) for k, v in s.items()}
        except Exception as exc:  # noqa: BLE001
            counts[n] = f'{type(exc).__name__}: {exc}'[:200]
    p5['min_pairs'] = counts
    # invalid inputs and their messages
    invalid = {
        'no pairs.csv': byod_zip(base_records[:8], drop_csv=True),
        'missing label column': byod_zip(base_records[:8], cols=('id', 'before', 'after')),
        'csv names a member absent from the zip': byod_zip(base_records[:8], missing_member=True),
        'images in a subfolder, csv names subfolder paths': byod_zip(base_records[:8], prefix='imgs/'),
    }
    msgs = {}
    for name, payload in invalid.items():
        p = WORK / 'bad.zip'
        p.write_bytes(payload)
        try:
            recs = ns['load_byod_dataset'](p)
            msgs[name] = f'accepted ({len(recs)} records)'
        except Exception as exc:  # noqa: BLE001
            msgs[name] = f'{type(exc).__name__}: {exc}'[:200]
    p5['invalid'] = msgs
    # the real flow: cell 15 with USE_BYOD = True and a 12-pair upload, then Section 5 (cell 17)
    UPLOAD.clear()
    UPLOAD['my_pairs.zip'] = byod_zip(base_records[:12])
    src15 = setparam(code[15], 'USE_BYOD', 'True')
    p5['cells'] = [run(15, src15), run(17)]
    if p5['cells'][0]['ok']:
        p5['splits'] = {k: len(v) for k, v in ns['splits'].items()}
        p5['data_source'] = ns['data_source']
    results['probes']['P5_byod'] = p5
    save()


# ---------------- P6: is the selection criterion (validation loss) deterministic? ----------------
# adapt()'s val_loss() includes the content-consistency terms, which sample random pixel pairs from a generator
# that advances through training. Re-score the same weights with 10 generator seeds, and split off the
# deterministic MSE (change) term, for the frozen model and for the default kept epoch.
if ok_default:
    import torch

    def val_terms(pipe, records, seeds=range(10), batch_size=4):
        import numpy as np

        totals, mses = [], None
        for seed in seeds:
            gen = torch.Generator(device='cpu').manual_seed(seed)
            losses, mse = [], []
            for s in range(0, len(records), batch_size):
                b = records[s:s + batch_size]
                change, m1, m2, foc = pipe._change_map(np.stack([r['before'] for r in b]), np.stack([r['after'] for r in b]), grad=False, with_content=True)
                target = torch.from_numpy(np.stack([r['label'] for r in b])).to(pipe.device)
                losses.append(float(pipe._loss(change, m1, m2, foc, target, gen)))
                valid = target != -1
                mse.append(float(torch.nn.functional.mse_loss(change[valid], target.float()[valid])))
            totals.append(sum(losses) / len(losses))
            mses = sum(mse) / len(mse)
        return {'total_by_seed': [round(t, 5) for t in totals], 'total_min': round(min(totals), 5), 'total_max': round(max(totals), 5), 'mse_term': round(mses, 5)}

    p6: dict = {}
    run(15)  # default sample splits again (P5 replaced them with the BYOD upload)
    run(13)  # fresh base
    p6['frozen'] = val_terms(ns['pipe'], ns['val_records'])
    run(19)  # default adaptation
    p6['kept_history'] = [{'epoch': e['epoch'], 'val_loss': round(e['val_loss'], 5)} for e in ns['adapt_result']['history']]
    p6['kept_epoch'] = ns['adapt_result']['best_epoch']
    p6['kept'] = val_terms(ns['pipe'], ns['val_records'])
    p6['kept_test_f1'] = ns['pipe'].evaluate(ns['test_records'])['model']['f1']
    results['probes']['P6_selection_noise'] = p6
    save()

print('done')
save()
